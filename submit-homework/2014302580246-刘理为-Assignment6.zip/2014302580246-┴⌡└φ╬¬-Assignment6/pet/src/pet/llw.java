package pet;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;



import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class llw {
	static Vector<petinformation> all_information=new Vector<petinformation>();
	public static void main(String[] args) throws SQLException, ClassNotFoundException{
		String driver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://127.0.0.1:3306/llw?user=root&password=123456";
		String user="root";
		String password="123456";
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url, user, password);
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM llw.new_table";
		ResultSet selectRes = st.executeQuery(selectSql);
		while(selectRes.next()){
			petinformation i= new petinformation();
			i.id=selectRes.getInt("id");
			i.name=selectRes.getString("name");
			i.eat=selectRes.getString("eat");
			i.drink=selectRes.getString("drink");
			i.live=selectRes.getString("live");
			i.hobby=selectRes.getString("hobby");
			i.price=selectRes.getDouble("price");
			all_information.add(i);
		}
		EventQueue.invokeLater(new Runnable(){
			public void run()
			{
				JFrame frame=new ComponentFrame();
				frame.setTitle("pet");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
	public static String search(){
			String str1="";
			for(int d=6;d>=0;d--){
				for(petinformation i:all_information){
					str1+="id:"+i.id+"  "+"name:"+i.name+"  "+"eat:"+i.eat+"  "+"drink:"+i.drink+"  "+"live:"+i.live+"  "+"hobby:"+i.hobby+"  "+"price:"+i.price+"  "+"\n";
				}
			}
			return str1;
		}
static	public class ComponentFrame extends JFrame
	{
		public static final int TEXTAREA_ROWS=8;
		public static final int TEXTAREA_COLUMNS=20;
		public ComponentFrame(){
			final JTextField textField= new JTextField();
			final JPasswordField passwordField=new JPasswordField();
			JPanel northPanel = new JPanel();
			northPanel.setLayout(new GridLayout(2,2));
			northPanel.add(new JLabel("user name:",SwingConstants.RIGHT));
			northPanel.add(textField);
			northPanel.add(new JLabel("Password:",SwingConstants.RIGHT));
			northPanel.add(passwordField);
			add(northPanel,BorderLayout.NORTH);
			final JTextArea textArea=new JTextArea(TEXTAREA_ROWS,TEXTAREA_COLUMNS);
			JScrollPane scrollPane = new JScrollPane(textArea);
			add(scrollPane,BorderLayout.CENTER);
			JPanel southPanel = new JPanel();
			JButton insertButton = new JButton("��¼");
			southPanel.add(insertButton);
			insertButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent event){
					textArea.append(search());
				}	
			});
			add(southPanel,BorderLayout.SOUTH);
			pack();
		}
	}
static class petinformation{
		public int id;
		public String name;
		public String eat;
		public String drink;
		public String live;
		public String hobby;
		public double price;
	}
}
