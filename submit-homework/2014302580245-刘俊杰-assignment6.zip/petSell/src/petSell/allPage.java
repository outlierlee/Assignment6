package petSell;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.SQLException;


public class allPage {
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		//for test
		//db.addUser(new user("wildworm",123540));
		//db.write_pet_message(new pet_message("mm2","snack",997,"hehe"));
		//System.out.print("test succeed");
		//System.out.println(db.isTrue(new user("ljj2",654321)));
		//System.out.println(db.isDoubled(new pet_message("hha","cat",998,"nice")));
		load l=new load();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension size = l.getSize();
		int x = (screenSize.width - size.width) / 2;
		int y = (screenSize.height - size.height) / 2;
		l.setLocation( x, y );
		l.setVisible(true);
		//end test
	}
}
