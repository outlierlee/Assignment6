package petSell;

public class user {
	public String user_name;
	public int password;
	public user(String u,int p){
		user_name=u;
		password=p;
	}
	public user() {
		// TODO Auto-generated constructor stub
		user_name=null;
		password=0;
	}
}
