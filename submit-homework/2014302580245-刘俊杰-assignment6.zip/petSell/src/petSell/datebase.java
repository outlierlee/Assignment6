package petSell;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class datebase {
	String driver="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://127.0.0.1:3306/my_schema?seUnicode=true&characterEncoding=UTF-8";
	String user="root";
	String password="123456";
	Connection conn;
	public datebase() throws ClassNotFoundException, SQLException{
		Class.forName(driver);
		conn=DriverManager.getConnection(url, user, password);
	}
	public boolean isTrue(user u) throws SQLException{
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM my_schema.2014302580245_user";
		ResultSet selectRes=st.executeQuery(selectSql);
		while(selectRes.next()){
			if(u.password==selectRes.getInt("password")&&(u.user_name).equals(selectRes.getString("user"))){
				return true;
			}
		}
		return false;
	}
	public void addUser(user u) throws SQLException{
		if(isTrue(u)){
			return;
		}
		Statement st=conn.createStatement();
		String sqlexcute="INSERT INTO `my_schema`.`2014302580245_user` (`user`, `password`) VALUES ('"+u.user_name+"', '"+u.password+"');";
		st.executeUpdate(sqlexcute);
	}
	public boolean isDoubled(pet_message pt) throws SQLException{
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM my_schema.2014302580245_petmessage";
		ResultSet selectRes=st.executeQuery(selectSql);
		while(selectRes.next()){
			if((pt.pet_name).equals(selectRes.getString("pet_name"))){
				return true;
			}
		}
		return false;
	}
	@SuppressWarnings("null")
	public String getPetString() throws SQLException{
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM my_schema.2014302580245_petmessage";
		ResultSet selectRes=st.executeQuery(selectSql);
		String str=null;
		while(selectRes.next()){
			str+="name:"+selectRes.getString("pet_name")
			+"\n"+"kind"+selectRes.getString("pet_kind")
			+"\n"+"price:"+selectRes.getInt("pet_price")
			+"\n"+"other message:"+selectRes.getString("pet_other_message")+"\n\n\n";
		}
		return str;
		
	}
	public void write_pet_message(pet_message pt) throws SQLException{
		if(isDoubled(pt)){
			return;
		}
		Statement st=conn.createStatement();
		String sqlexcute="INSERT INTO `my_schema`.`2014302580245_petmessage` (`pet_name`, `pet_kind`, `pet_price`,`pet_other_message`) VALUES ('"+pt.pet_name+"', '"+pt.pet_kind+"', '"+pt.pet_price+"','"+pt.pet_other_message+"');";
		st.executeUpdate(sqlexcute);
	}
}
