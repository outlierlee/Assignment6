package petSell;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class load extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public load() throws ClassNotFoundException, SQLException{
		datebase db=new datebase();
		JPanel panel=new JPanel();
		JButton loadButton=new JButton("����");
		JTextField input=new JTextField("",10);
		JPasswordField password=new JPasswordField("",10);
		panel.setLayout(new GridLayout(3,1));
		panel.add(input);
		panel.add(password);
		panel.add(loadButton);
		add(panel);
		setSize(270,165);
		loadButton.addActionListener(new ActionListener(){
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent event){
					user inputUser=new user();
					inputUser.user_name=input.getText();
					inputUser.password=Integer.valueOf(password.getText()).intValue();
					try {
						if(db.isTrue(inputUser)){
							setVisible(false);
							System.out.println("true");
							mainGUI m=new mainGUI();
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		});
		
	}

}
