package petSell;

public class pet_message {
	public String pet_name;
	public String pet_kind;
	public int pet_price;
	public String pet_other_message;
	public pet_message(){
		
	}
	public pet_message(String n,String k,int p,String o)
	{
		pet_name=n;
		pet_kind=k;
		pet_price=p;
		pet_other_message=o;
	}
}
