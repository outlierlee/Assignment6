package petSell;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class mainGUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public mainGUI() throws SQLException, ClassNotFoundException{
		datebase db=new datebase();
		JPanel panel=new JPanel();
		JButton loadButton=new JButton("����");
		JTextField input=new JTextField("������Ҫ������������",10);
		JTextArea out=new JTextArea(10,40);
		JScrollPane sc=new JScrollPane(out);
		out.setText(db.getPetString());
		add(sc,BorderLayout.CENTER);
		panel.setLayout(new GridLayout(1,2));
		panel.add(input);
		panel.add(loadButton);
		add(panel,BorderLayout.SOUTH);
		setSize(270,165);
		loadButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				JOptionPane.showMessageDialog(null, "����ɹ���лл�ݹ�", "succeed", JOptionPane.ERROR_MESSAGE); 
			}
		});
		setSize(500,350);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension size = getSize();
		int x = (screenSize.width - size.width) / 2;
		int y = (screenSize.height - size.height) / 2;
		setLocation( x, y );
		setVisible(true);
	}
}
